# Clip Ur Friends

A ready-to-deploy order website for custom friend videos.

## What it does
- Lets customers upload 8–12 photos.
- Lets them enter the people in the video, song, colors, and notes.
- Collects first name, last name, and email/phone.
- Sends the order information and uploaded photos to your email through Resend.
- Gives the customer an order number after successful submission.

## Setup
1. Install Node.js.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Create a Resend account and verify the sending domain/email.
5. Put your Resend API key in `RESEND_API_KEY`.
6. Put the email where you want orders delivered in `OWNER_EMAIL`.
7. Put your verified sender address in `FROM_EMAIL`.
8. Run `npm start`.
9. Open `http://localhost:3000`.

## Important
The website does not download or provide copyrighted songs. Customers simply tell you which song they want, and you can use the music in your editing workflow according to the platform/license rules that apply to you.
