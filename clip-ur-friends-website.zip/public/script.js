const form = document.getElementById("orderForm");
const photos = document.getElementById("photos");
const preview = document.getElementById("preview");
const fileText = document.getElementById("fileText");
const status = document.getElementById("status");

photos.addEventListener("change", () => {
  preview.innerHTML = "";
  const files = [...photos.files];
  fileText.textContent = files.length ? `${files.length} picture${files.length === 1 ? "" : "s"} selected` : "No pictures selected";

  if (files.length < 8 || files.length > 12) {
    status.textContent = "Please choose between 8 and 12 pictures.";
    status.style.color = "#d22";
  } else {
    status.textContent = "";
  }

  files.forEach(file => {
    const img = document.createElement("img");
    img.alt = file.name;
    img.src = URL.createObjectURL(file);
    preview.appendChild(img);
  });
});

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  status.style.color = "";
  status.textContent = "Sending your order…";

  if (photos.files.length < 8 || photos.files.length > 12) {
    status.textContent = "Please upload 8–12 pictures.";
    status.style.color = "#d22";
    return;
  }

  const data = new FormData(form);
  try {
    const response = await fetch("/api/order", { method: "POST", body: data });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Order failed.");

    status.textContent = `Order sent! Your order number is ${result.orderNumber}.`;
    status.style.color = "#168a4b";
    form.reset();
    preview.innerHTML = "";
    fileText.textContent = "No pictures selected";
    window.scrollTo({ top: document.getElementById("order").offsetTop - 80, behavior: "smooth" });
  } catch (err) {
    status.textContent = err.message;
    status.style.color = "#d22";
  }
});
