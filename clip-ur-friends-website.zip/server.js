const express = require("express");
const multer = require("multer");
const path = require("path");
const dotenv = require("dotenv");
const { Resend } = require("resend");

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { files: 12, fileSize: 12 * 1024 * 1024 },
  fileFilter: (_, file, cb) => {
    const ok = ["image/jpeg", "image/png", "image/webp", "image/heic"].includes(file.mimetype);
    cb(ok ? null : new Error("Only JPG, PNG, WEBP, or HEIC images are allowed."), ok);
  }
});

app.use(express.static(path.join(__dirname, "public")));

app.post("/api/order", upload.array("photos", 12), async (req, res) => {
  try {
    if (!process.env.RESEND_API_KEY || !process.env.OWNER_EMAIL || !process.env.FROM_EMAIL) {
      return res.status(500).json({ error: "Email service is not configured yet." });
    }

    const { firstName, lastName, contact, people, song, colors, notes } = req.body;
    const photos = req.files || [];

    if (!firstName || !lastName || !contact || !people || !song || !colors) {
      return res.status(400).json({ error: "Please complete every required field." });
    }
    if (photos.length < 8 || photos.length > 12) {
      return res.status(400).json({ error: "Please upload between 8 and 12 pictures." });
    }

    const orderNumber = `CUF-${Date.now().toString().slice(-8)}`;
    const photoSummary = photos.map((f, i) => `${i + 1}. ${f.originalname}`).join("\n");

    const html = `
      <h2>New Clip Ur Friends order — ${orderNumber}</h2>
      <p><strong>Customer:</strong> ${firstName} ${lastName}</p>
      <p><strong>Contact:</strong> ${contact}</p>
      <p><strong>People in the video:</strong> ${escapeHtml(people)}</p>
      <p><strong>Song:</strong> ${escapeHtml(song)}</p>
      <p><strong>Main colors:</strong> ${escapeHtml(colors)}</p>
      <p><strong>Notes:</strong> ${escapeHtml(notes || "None")}</p>
      <p><strong>Pictures:</strong> ${photos.length} attached</p>
      <ul>${photos.map(f => `<li>${escapeHtml(f.originalname)}</li>`).join("")}</ul>
    `;

    const resend = new Resend(process.env.RESEND_API_KEY);
    const attachments = photos.map(f => ({
      filename: f.originalname,
      content: f.buffer.toString("base64")
    }));

    await resend.emails.send({
      from: process.env.FROM_EMAIL,
      to: [process.env.OWNER_EMAIL],
      subject: `New Clip Ur Friends order ${orderNumber}`,
      html,
      attachments
    });

    res.json({ ok: true, orderNumber });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message || "Something went wrong. Please try again." });
  }
});

function escapeHtml(value = "") {
  return String(value).replace(/[&<>"']/g, c => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
  }[c]));
}

app.use((err, req, res, next) => {
  if (err) return res.status(400).json({ error: err.message });
  next();
});

app.listen(PORT, () => console.log(`Clip Ur Friends running on port ${PORT}`));
